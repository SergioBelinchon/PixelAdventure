<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="git" name="tiledFakemon" tilewidth="16" tileheight="16" tilecount="2376" columns="54">
 <image source="../../../../fakemon/assets/images/terreno/terreno.png" width="864" height="705"/>
</tileset>
