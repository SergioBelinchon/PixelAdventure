import 'package:flame/components.dart';

import '../../fakemon.dart';

class Ciudad extends World with HasGameRef<Fakemon>
{
 /* final String nombreCiudad;
  final Player player;

  Ciudad({required this.nombreCiudad, required this.player1, required this.player2});
  late TiledComponent level;
  */

}