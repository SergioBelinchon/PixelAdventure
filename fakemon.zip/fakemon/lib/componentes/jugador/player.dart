import 'dart:async';

import 'package:fakemon/componentes/jugador/utils.dart';
import 'package:fakemon/fakemon.dart';
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';


import 'colision_bloque.dart';
import 'custom_hitbox.dart';

enum PlayerState {inactivo, corriendo}


class Player extends SpriteAnimationGroupComponent
    with HasGameRef<Fakemon>, KeyboardHandler, CollisionCallbacks {
  
  String personaje;
  Player({
    position,
    this.personaje = 'Pink Man',
  }) : super(position: position);

  final double stepTime = 0.05;

  late final SpriteAnimation animacionInactivo;
  late final SpriteAnimation animacionCorriendo;


  Vector2 startingPosition = Vector2.zero();
  double horizontalMovement = 0;
  double verticalMovement = 0;

  double moveSpeed = 100;
  Vector2 velocity = Vector2.zero();
  List<ColisionBloque> colisionBloques = [];

  CustomHitbox hitbox = CustomHitbox(
    offsetX: 10,
    offsetY: 4,
    width: 14,
    height: 28,
  );

  double fixedDeltaTime = 1 / 60;
  double accumulatedTime = 0;


  @override
  FutureOr<void> onLoad() {
    _loadAllAnimations();

    //debugMode = true;

    startingPosition = Vector2(position.x, position.y);

    add(RectangleHitbox(
      position: Vector2(hitbox.offsetX, hitbox.offsetY),
      size: Vector2(hitbox.width, hitbox.height),
    ));
    return super.onLoad();
  }

  @override
  void update(double dt)
  {
    accumulatedTime += dt;

    while(accumulatedTime >= fixedDeltaTime)
    {
      accumulatedTime -= fixedDeltaTime;
    }
    super.update(dt);
  }

  @override
  bool onKeyEvent(RawKeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    horizontalMovement = 0;
    verticalMovement = 0;
    final isLeftKeyPressed = keysPressed.contains(LogicalKeyboardKey.keyA) ||
        keysPressed.contains(LogicalKeyboardKey.arrowLeft);
    final isRightKeyPressed = keysPressed.contains(LogicalKeyboardKey.keyD) ||
        keysPressed.contains(LogicalKeyboardKey.arrowRight);
    final isDownKeyPressed = keysPressed.contains(LogicalKeyboardKey.keyS) ||
        keysPressed.contains(LogicalKeyboardKey.arrowDown);
    final isUpKeyPressed = keysPressed.contains(LogicalKeyboardKey.keyW) ||
        keysPressed.contains(LogicalKeyboardKey.arrowUp);

    horizontalMovement += isLeftKeyPressed ? -1 : 0;
    horizontalMovement += isRightKeyPressed ? 1 : 0;
    verticalMovement += isDownKeyPressed ? 1 : 0;
    verticalMovement += isUpKeyPressed ? -1 : 0;

    return super.onKeyEvent(event, keysPressed);
  }

  void _loadAllAnimations()
  {
    animacionInactivo = _spriteAnimation('Inactivo', 11);
    animacionCorriendo = _spriteAnimation('Corriendo', 12);

    //Lista de animaciones
    animations = {
      PlayerState.inactivo: animacionInactivo,
      PlayerState.corriendo: animacionCorriendo,
    };
    //Set animacion
    current = PlayerState.inactivo;
  }

  SpriteAnimation _spriteAnimation(String state, int amount) {
    return SpriteAnimation.fromFrameData(
      game.images.fromCache('characters/$personaje/$state (32x32).png'),
      SpriteAnimationData.sequenced(
        amount: amount,
        stepTime: stepTime,
        textureSize: Vector2.all(32),
      ),
    );
  }

  void _updatePlayerState() {
    PlayerState playerState = PlayerState.inactivo;

    if (velocity.x < 0 && scale.x > 0) {
      flipHorizontallyAroundCenter();
    } else if (velocity.x > 0 && scale.x < 0) {
      flipHorizontallyAroundCenter();
    }

    //Si se mueve, corre
    if (velocity.x > 0 || velocity.x < 0 || velocity.y > 0 || velocity.y < 0) playerState = PlayerState.corriendo;

    current = playerState;
  }

  void _updatePlayerMovement(double dt) {

    //if(velocity.y > _gravedad) isEnSuelo = false; //Opcional
    velocity.y = verticalMovement * moveSpeed;
    position.x += velocity.x * dt;
    position.y += velocity.y * dt;
    velocity.x = horizontalMovement * moveSpeed;


  }


  void _checkHorizontalColisiones() {
    for (final bloque in colisionBloques) {
      if (checkColision(this, bloque)) {
        if (velocity.x > 0) {
          velocity.x = 0;
          position.x = bloque.x - hitbox.offsetX - hitbox.width;
          break;
        }
        if (velocity.x < 0) {
          velocity.x = 0;
          position.x =
              bloque.x + bloque.width + hitbox.width + hitbox.offsetX;
          break;
        }
      }
    }
  }


  void _checkVerticalColisiones() {
    for (final bloque in colisionBloques) {
      if (checkColision(this, bloque)) {
        if (velocity.y > 0) {
          velocity.y = 0;
          position.y = bloque.y - hitbox.height - hitbox.offsetY;
          break;
        }
      }
      else {
        if (checkColision(this, bloque)) {
          if (velocity.y > 0) {
            velocity.y = 0;
            position.y = bloque.y - hitbox.height - hitbox.offsetY;
            break;
          }
          if (velocity.y < 0) {
            velocity.y = 0;
            position.y = bloque.y + bloque.height - hitbox.offsetY;
          }
        }
      }
    }
  }

/*
  void _respawn() async
  {
    const canMoveDuration = Duration(milliseconds: 400);

    gotHit = true;
    current = PlayerState.hit;

    await animationTicker?.completed;
    animationTicker?.reset();

    scale.x = 1;
    position = startingPosition - Vector2.all(32);
    current = PlayerState.appearing;

    await animationTicker?.completed;
    animationTicker?.reset();

    velocity = Vector2.zero();
    position = startingPosition;
    _updatePlayerState();
    Future.delayed(canMoveDuration, () => gotHit = false);

  }


 void _reachedCheckpoint()
  {
    reachedCheckpoint = true;
    if(scale.x > 0)
    {
      position = position - Vector2.all(32);
    }
    else if(scale.x < 0)
    {
      position = position + Vector2(32, -32);
    }
    current = PlayerState.disappearing;

    const reachedCheckpointDuration = Duration(milliseconds: 350);
    Future.delayed(reachedCheckpointDuration, ()
    {
      reachedCheckpoint = false;
      position = Vector2.all(-600);

      const waitToChangeDuration = Duration(seconds: 3);
      Future.delayed(waitToChangeDuration, ()
      {
        // elegir nivel
        game.loadNextLevel();
      });
    });
  }*/
}



