import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PartidaNueva extends StatefulWidget {
  @override
  _PartidaNuevaState createState() => _PartidaNuevaState();
}

class _PartidaNuevaState extends State<PartidaNueva> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'PARTIDA NUEVA',
          style: GoogleFonts.getFont(
            'Kdam Thmor Pro',
            textStyle: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ),
      body: const Center(
        child: Text(
          '¡Bienvenido a tu nueva partida!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
