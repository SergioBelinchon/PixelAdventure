import 'package:flutter/material.dart';
import 'componentes/pantallas/pantallaInicio.dart';

void main() {
  runApp(FakemonApp());
}

class FakemonApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: PantallaInicio(),
    );
  }
}