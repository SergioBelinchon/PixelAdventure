
import 'dart:async';

import 'package:flame/camera.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';


class Fakemon extends FlameGame
    with
        HasKeyboardHandlerComponents,
        DragCallbacks,
        HasCollisionDetection,
        TapCallbacks
{
  late CameraComponent camara;

  @override
  FutureOr<void> onLoad() async
  {
    //Carga todas las imagenes del cache
    await images.loadAllImages();

    _loadLevel();

  }

  void _loadLevel()
  {
    Future.delayed(const Duration(seconds: 1,)
        , ()
        async {
          Level world = Level(
            player1: player1,
            player2: player2,
            levelName: levelNames[currentLevelIndex],
          );

          camara = CameraComponent.withFixedResolution(
            world: world,
            width: 640,
            height: 360,
          );
          camara.viewfinder.anchor = Anchor.topLeft;

          camara.viewport.add(Hud());

          addAll([camara, world]);
        });

  }
}