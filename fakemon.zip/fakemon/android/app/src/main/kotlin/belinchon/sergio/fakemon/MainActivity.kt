package belinchon.sergio.fakemon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
